module.exports = {
    Config_DevMode: true
}