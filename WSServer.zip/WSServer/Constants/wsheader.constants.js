module.exports = {
    WS_Header_Init: "Init",
    WS_Header_StartRoom: "RoomStart",
    WS_Header_CheckPlayer: "CheckPlayer",
    WS_Header_Finished: "Finished",
    WS_Header_Claim: "Claim"
}